/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.nereusstream.metadata.oxia.v2.continuity;

/** Non-blocking, coalescing handoff to a future authoritative revalidation owner. */
public interface RevalidationScheduler extends AutoCloseable {
    /** Returns false if the request cannot be accepted; rejection keeps the store fail closed. */
    boolean request(long clientGeneration, long invalidationEpoch);

    /** Stops admission and drains or cancels work according to the owned local executor contract. */
    @Override
    void close();
}
