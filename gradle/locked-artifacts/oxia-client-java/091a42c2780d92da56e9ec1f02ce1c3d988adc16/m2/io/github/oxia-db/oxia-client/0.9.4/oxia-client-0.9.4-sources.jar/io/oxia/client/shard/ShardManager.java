/*
 * Copyright © 2022-2025 The Oxia Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.oxia.client.shard;

import static com.google.common.base.Throwables.getRootCause;
import static io.oxia.client.grpc.OxiaStatusCode.NAMESPACE_NOT_FOUND;
import static io.oxia.client.shard.HashRangeShardStrategy.Xxh332HashRangeShardStrategy;
import static java.util.Collections.unmodifiableMap;
import static java.util.Collections.unmodifiableSet;
import static java.util.function.Function.identity;
import static java.util.stream.Collectors.toMap;
import static java.util.stream.Collectors.toSet;

import com.google.common.annotations.VisibleForTesting;
import io.github.merlimat.slog.Logger;
import io.grpc.stub.StreamObserver;
import io.opentelemetry.api.common.Attributes;
import io.oxia.client.CompositeConsumer;
import io.oxia.client.grpc.OxiaStatusException;
import io.oxia.client.grpc.RpcProvider;
import io.oxia.client.metrics.Counter;
import io.oxia.client.metrics.InstrumentProvider;
import io.oxia.client.metrics.Unit;
import io.oxia.client.util.Backoff;
import io.oxia.proto.NamespaceShardsAssignment;
import io.oxia.proto.ShardAssignments;
import io.oxia.proto.ShardAssignmentsRequest;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.stream.Stream;
import lombok.NonNull;

public class ShardManager implements AutoCloseable, StreamObserver<ShardAssignments> {

    private final Logger log;
    private final ScheduledExecutorService asyncExecutor;
    private final RpcProvider rpcProvider;
    private final ShardAssignmentsContainer assignments;
    private final CompositeConsumer<ShardAssignmentChanges> callbacks;
    private final Set<ShardAssignmentContinuityListener> continuityListeners;

    private final Backoff backoff = new Backoff();
    private final CompletableFuture<Void> initialAssignmentsFuture;

    private volatile boolean closed;
    private long continuityGeneration;
    private ShardAssignmentContinuitySnapshot continuitySnapshot;

    private final Counter shardAssignmentsEvents;

    public ShardManager(
            @NonNull ScheduledExecutorService asyncExecutor,
            @NonNull RpcProvider rpcProvider,
            @NonNull InstrumentProvider instrumentProvider,
            @NonNull String namespace) {
        this.rpcProvider = rpcProvider;
        this.asyncExecutor = asyncExecutor;
        this.assignments = new ShardAssignmentsContainer(Xxh332HashRangeShardStrategy, namespace);
        this.callbacks = new CompositeConsumer<>();
        this.continuityListeners = new HashSet<>();
        this.initialAssignmentsFuture = new CompletableFuture<>();
        this.continuityGeneration = 1;
        this.continuitySnapshot =
                new ShardAssignmentContinuitySnapshot(
                        continuityGeneration, ShardAssignmentContinuityState.ARMING, Set.of());
        this.log =
                Logger.get(ShardManager.class).with().attr("namespace", assignments.getNamespace()).build();

        this.shardAssignmentsEvents =
                instrumentProvider.newCounter(
                        "oxia.client.shard.assignments.count",
                        Unit.None,
                        "The total count of received shard assignment events",
                        Attributes.empty());
    }

    @Override
    public void close() {
        synchronized (this) {
            if (closed) {
                return;
            }
            closed = true;
        }
        publishContinuity(ShardAssignmentContinuityState.CLOSED, allShardsSnapshot(), true);
    }

    public CompletableFuture<Void> start() {
        var req = new ShardAssignmentsRequest();
        req.setNamespace(assignments.getNamespace());

        rpcProvider.getShardAssignments(req, this);
        return initialAssignmentsFuture;
    }

    @Override
    public void onNext(ShardAssignments assignments) {
        if (closed) {
            return;
        }
        shardAssignmentsEvents.increment();
        updateAssignments(assignments);
        backoff.reset();
        if (!initialAssignmentsFuture.isDone()) {
            initialAssignmentsFuture.complete(null);
        }
    }

    @Override
    public void onError(Throwable error) {
        if (closed) {
            return;
        }

        final var oxiaError = OxiaStatusException.from(error);
        if (oxiaError.getStatusCode() == NAMESPACE_NOT_FOUND && !initialAssignmentsFuture.isDone()) {
            log.error("Namespace not found");
            if (initialAssignmentsFuture.completeExceptionally(
                    new NamespaceNotFoundException(assignments.getNamespace()))) {
                close();
                return;
            }
        }
        publishContinuity(ShardAssignmentContinuityState.ARMING, allShardsSnapshot(), true);
        log.warn().exceptionMessage(getRootCause(error)).log("Failed receiving shard assignments");
        asyncExecutor.schedule(
                () -> {
                    if (!closed) {
                        log.info("Retry creating stream for shard assignments");
                        start();
                    }
                },
                backoff.nextDelayMillis(),
                TimeUnit.MILLISECONDS);
    }

    @Override
    public void onCompleted() {
        if (closed) {
            return;
        }

        publishContinuity(ShardAssignmentContinuityState.ARMING, allShardsSnapshot(), true);
        log.warn("Stream closed while receiving shard assignments");
        asyncExecutor.schedule(
                () -> {
                    if (!closed) {
                        log.info("Retry creating stream for shard assignments after stream closed");
                        start();
                    }
                },
                backoff.nextDelayMillis(),
                TimeUnit.MILLISECONDS);
    }

    private void updateAssignments(io.oxia.proto.ShardAssignments shardAssignments) {
        NamespaceShardsAssignment nsSharedAssignments;
        try {
            nsSharedAssignments = shardAssignments.getNamespaces(assignments.getNamespace());
        } catch (IllegalArgumentException e) {
            nsSharedAssignments = null;
        }
        if (nsSharedAssignments == null) {
            /*
            It shouldn't happen, but we have to do some defensive programming to avoid server nodes
            Allowing namespaces to be deleted in the future.

            Retries are available so that the client does not panic until the namespace is recreated.
            */
            throw new NamespaceNotFoundException(assignments.getNamespace(), true);
        }
        var updates =
                nsSharedAssignments.getAssignmentsList().stream().map(Shard::fromProto).collect(toSet());
        var updatedMap = recomputeShardHashBoundaries(assignments.allShards(), updates);
        var changes = computeShardLeaderChanges(assignments.allShards(), updatedMap);
        assignments.update(changes);
        publishContinuity(ShardAssignmentContinuityState.READY, allShardsSnapshot(), false);
        callbacks.accept(changes);
    }

    @VisibleForTesting
    static Map<Long, Shard> recomputeShardHashBoundaries(
            Map<Long, Shard> assignments, Set<Shard> updates) {
        var toDelete = new ArrayList<>();
        var log = Logger.get(ShardManager.class);
        for (var update : updates) {
            for (var existing : update.findOverlapping(assignments.values())) {
                log.info()
                        .attr("existing", existing)
                        .attr("update", update)
                        .log("Deleting shard as it overlaps");
                toDelete.add(existing.id());
            }
        }

        return unmodifiableMap(
                Stream.concat(
                                assignments.entrySet().stream()
                                        .filter(e -> !toDelete.contains(e.getKey()))
                                        .map(Map.Entry::getValue),
                                updates.stream())
                        .collect(
                                toMap(
                                        Shard::id,
                                        identity(),
                                        // merge function to avoid throw any exception when receive unchanged events
                                        (existing, newValue) -> newValue)));
    }

    @VisibleForTesting
    static ShardAssignmentChanges computeShardLeaderChanges(
            Map<Long, Shard> oldAssignments, Map<Long, Shard> newAssignments) {
        Set<Shard> removed =
                oldAssignments.values().stream()
                        .filter(shard -> !newAssignments.containsKey(shard.id()))
                        .collect(toSet());
        Set<Shard> added =
                newAssignments.values().stream()
                        .filter(shard -> !oldAssignments.containsKey(shard.id()))
                        .collect(toSet());
        Set<Shard> changed =
                oldAssignments.values().stream()
                        .filter(s -> newAssignments.containsKey(s.id()))
                        .filter(s -> !newAssignments.get(s.id()).leader().equals(s.leader()))
                        .map(s -> newAssignments.get(s.id())) // return reassigned leader
                        .collect(toSet());
        return new ShardAssignmentChanges(
                unmodifiableSet(added), unmodifiableSet(removed), unmodifiableSet(changed));
    }

    public record ShardAssignmentChanges(
            Set<Shard> added, Set<Shard> removed, Set<Shard> reassigned) {}

    public long getShardForKey(String key) {
        return assignments.getShardForKey(key);
    }

    public Collection<Shard> allShards() {
        return assignments.allShards().values();
    }

    public Set<Long> allShardIds() {
        return assignments.allShardIds();
    }

    public String leader(long shardId) {
        return assignments.leader(shardId);
    }

    public void addCallback(@NonNull Consumer<ShardAssignmentChanges> callback) {
        callbacks.add(callback);
    }

    public void removeCallback(@NonNull Consumer<ShardAssignmentChanges> callback) {
        callbacks.remove(callback);
    }

    public synchronized void addContinuityListener(
            @NonNull ShardAssignmentContinuityListener listener) {
        continuityListeners.add(listener);
        publishContinuityListener(listener, continuitySnapshot);
    }

    public synchronized void removeContinuityListener(
            @NonNull ShardAssignmentContinuityListener listener) {
        continuityListeners.remove(listener);
    }

    public synchronized ShardAssignmentContinuitySnapshot assignmentContinuity() {
        return continuitySnapshot;
    }

    private Set<Shard> allShardsSnapshot() {
        return Set.copyOf(assignments.allShards().values());
    }

    private void publishContinuity(
            ShardAssignmentContinuityState state, Set<Shard> assignment, boolean advanceGeneration) {
        final Set<ShardAssignmentContinuityListener> listeners;
        final ShardAssignmentContinuitySnapshot snapshot;
        synchronized (this) {
            if (closed && state != ShardAssignmentContinuityState.CLOSED) {
                return;
            }
            if (advanceGeneration) {
                if (continuityGeneration == Long.MAX_VALUE) {
                    throw new IllegalStateException("shard assignment continuity generation overflow");
                }
                continuityGeneration += 1;
            }
            snapshot =
                    new ShardAssignmentContinuitySnapshot(
                            continuityGeneration, state, Set.copyOf(assignment));
            continuitySnapshot = snapshot;
            listeners = Set.copyOf(continuityListeners);
        }
        listeners.forEach(listener -> publishContinuityListener(listener, snapshot));
    }

    private void publishContinuityListener(
            ShardAssignmentContinuityListener listener, ShardAssignmentContinuitySnapshot snapshot) {
        try {
            listener.onContinuityChange(snapshot);
        } catch (Throwable error) {
            log.warn().exceptionMessage(error).log("Shard assignment continuity listener failed");
        }
    }

    public enum ShardAssignmentContinuityState {
        ARMING,
        READY,
        CLOSED
    }

    public record ShardAssignmentContinuitySnapshot(
            long generation, ShardAssignmentContinuityState state, Set<Shard> assignment) {
        public ShardAssignmentContinuitySnapshot {
            if (generation <= 0) {
                throw new IllegalArgumentException("generation must be positive");
            }
            state = java.util.Objects.requireNonNull(state, "state");
            assignment = Set.copyOf(assignment);
        }
    }

    @FunctionalInterface
    public interface ShardAssignmentContinuityListener {
        void onContinuityChange(ShardAssignmentContinuitySnapshot snapshot);
    }
}
