/*
 * Copyright © 2022-2025 The Oxia Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.oxia.client.notify;

import static io.oxia.client.api.Notification.KeyModified;
import static lombok.AccessLevel.PACKAGE;

import io.github.merlimat.slog.Logger;
import io.oxia.client.CompositeConsumer;
import io.oxia.client.api.Notification;
import io.oxia.client.api.Notification.KeyCreated;
import io.oxia.client.api.Notification.KeyDeleted;
import io.oxia.client.grpc.RpcProvider;
import io.oxia.client.grpc.observer.CancelableStreamObserver;
import io.oxia.proto.NotificationBatch;
import io.oxia.proto.NotificationsRequest;
import java.io.Closeable;
import java.util.OptionalLong;
import java.util.function.Consumer;
import lombok.Getter;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

public class ShardNotificationReceiver extends CancelableStreamObserver<NotificationBatch>
        implements Closeable {

    private final Logger log;

    private final RpcProvider rpcProvider;
    private final NotificationManager notificationManager;

    @Getter(PACKAGE)
    private final long shardId;

    private final @NonNull Consumer<Notification> callback;

    @Getter private volatile @NonNull OptionalLong offset;

    private volatile boolean closed = false;

    ShardNotificationReceiver(
            @NonNull RpcProvider rpcProvider,
            long shardId,
            @NonNull Consumer<Notification> callback,
            @NonNull NotificationManager notificationManager,
            @NonNull OptionalLong offset) {
        this.rpcProvider = rpcProvider;
        this.notificationManager = notificationManager;
        this.shardId = shardId;
        this.callback = callback;
        this.offset = offset;
        this.log = Logger.get(ShardNotificationReceiver.class).with().attr("shard", shardId).build();
    }

    void start() {
        if (closed) {
            return;
        }
        var request = new NotificationsRequest();
        request.setShard(shardId);
        offset.ifPresent(request::setStartOffsetExclusive);
        try {
            rpcProvider.getNotifications(request, this);
        } catch (Throwable ex) {
            onError(ex);
        }
    }

    @Override
    protected void handleNext(NotificationBatch batch) {
        if (!notificationManager.onBatch(this, batch)) {
            return;
        }
        if (offset.isPresent() && offset.getAsLong() >= batch.getOffset()) {
            // Ignore repeated notifications
            return;
        }

        offset = OptionalLong.of(batch.getOffset());

        notificationManager.getCounterNotificationsBatchesReceived().increment();
        notificationManager.getCounterNotificationsReceived().add(batch.getNotificationsCount());

        batch.forEachNotifications(
                (key, notification) -> {
                    log.debug().attr("key", key).attr("type", notification.getType()).log("Got notification");

                    var n =
                            switch (notification.getType()) {
                                case KEY_CREATED -> new KeyCreated(key, notification.getVersionId());
                                case KEY_MODIFIED -> new KeyModified(key, notification.getVersionId());
                                case KEY_DELETED -> new KeyDeleted(key);
                                case KEY_RANGE_DELETED ->
                                        new Notification.KeyRangeDelete(key, notification.getKeyRangeLast());
                                default -> null;
                            };

                    if (n != null) {
                        callback.accept(n);
                    }
                });
    }

    @Override
    protected void handleError(Throwable t) {
        if (closed) {
            return;
        }
        notificationManager.onReceiverError(this, t);
    }

    @Override
    protected void handleComplete() {
        if (!closed) {
            notificationManager.onReceiverCompleted(this);
        }
    }

    @RequiredArgsConstructor(access = PACKAGE)
    static class Factory {
        private final @NonNull RpcProvider rpcProvider;

        @Getter
        private final @NonNull CompositeConsumer<Notification> callback = new CompositeConsumer<>();

        @NonNull
        ShardNotificationReceiver newReceiver(
                long shardId,
                @NonNull NotificationManager notificationManager,
                @NonNull OptionalLong offset) {
            return new ShardNotificationReceiver(
                    rpcProvider, shardId, callback, notificationManager, offset);
        }
    }

    @Override
    public void close() {
        this.closed = true;
        cancel();
    }
}
