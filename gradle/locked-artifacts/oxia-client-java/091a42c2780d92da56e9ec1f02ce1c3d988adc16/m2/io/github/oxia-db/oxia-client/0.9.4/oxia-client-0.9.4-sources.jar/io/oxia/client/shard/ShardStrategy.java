/*
 * Copyright © 2022-2026 The Oxia Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.oxia.client.shard;

import java.util.Collection;
import java.util.function.Predicate;
import lombok.NonNull;

interface ShardStrategy {
    @NonNull
    Predicate<Shard> acceptsKeyPredicate(@NonNull String key);

    /**
     * Builds the lookup structure used to route keys to shards. Invoked only when the shard
     * assignments change, while the returned router is queried on every operation.
     */
    @NonNull
    ShardRouter createRouter(@NonNull Collection<Shard> shards);
}
