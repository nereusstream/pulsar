/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.nereusstream.domain.protocol;

import com.nereusstream.domain.identity.DeploymentId;
import com.nereusstream.domain.identity.PulsarCellId;
import com.nereusstream.domain.identity.ReservationDomainId;
import java.util.Objects;

/** The Pulsar NPC1 Cell fields, including the reservation-domain identity. */
public record PulsarProtocolCellIdentity(
        DeploymentId deploymentId, ReservationDomainId reservationDomainId, PulsarCellId cellId)
        implements ProtocolCellIdentity {
    public PulsarProtocolCellIdentity {
        Objects.requireNonNull(deploymentId, "deploymentId");
        Objects.requireNonNull(reservationDomainId, "reservationDomainId");
        Objects.requireNonNull(cellId, "cellId");
    }

    @Override
    public ProtocolKindV1 protocolKind() {
        return ProtocolKindV1.PULSAR;
    }
}
